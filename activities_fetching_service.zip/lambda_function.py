import json, urllib, requests, boto3

def lambda_handler(event, context):
  # DynamoDB configuration
  dynamodb         = boto3.resource('dynamodb')
  users_table      = dynamodb.Table('strava_users')
  activities_table = dynamodb.Table('strava_activities')

  # Retrieve all users from the users table
  users = users_table.scan()['Items']

  for u in users:
    access_token = u['access_token']
    url = "https://www.strava.com/api/v3/athlete/activities"
    headers = {
      'Authorization': 'Bearer ' + access_token,
    }
    response = requests.get(url, headers=headers)
    activities = json.loads(response.content)
    for a in activities:
      activity = {
        'id': a['id'],
        'raw_content': json.dumps(a)
      }
      activities_table.put_item(Item=activity)


  # try:
  #
  #   users = json.loads(response.content)

  #   # Loop through existing Auth0 users
  #   for u in users:
  #     # Only select the Strava logged users
  #     if u['identities'][0]['connection']=='Strava':
  #       # Build a simplified representation of the user
  #       user = {
  #         "first_name": u['firstname'],
  #         "last_name": u['lastname'],
  #         "email": u['email'],
  #         "picture": u['picture'],
  #         "access_token": u['identities'][0]['access_token'],
  #         "updated_at": str(datetime.now())
  #       }
  #       # Insert the user in the DynamoDB table. Note that since email has
  #       # been defined as the primary key, the existing uses only get refreshed
  #       # which is pretty useful for our purpose
  #       table.put_item(Item=user)
  # except Exception as e:
  #   print(format(e))
